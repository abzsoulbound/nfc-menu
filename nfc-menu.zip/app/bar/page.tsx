"use client"

import { useEffect, useState } from "react"
import { MouseEvent } from "react"
import { StationQueue } from "@/components/bar/StationQueue"
import { TicketView } from "@/components/bar/TicketView"
import { Card } from "@/components/ui/Card"
import { Badge } from "@/components/ui/Badge"

type BarItem = {
  orderId: string
  tableNumber: number
  name: string
  quantity: number
  edits: any
  submittedAt: string
}

type TableGroup = {
  tableNumber: number
  items: BarItem[]
  submittedAt: string
}

export default function BarDashboard() {
  const [tables, setTables] = useState<TableGroup[]>([])
  const [activeTable, setActiveTable] = useState<number | null>(null)

  async function fetchQueue() {
    const res = await fetch("/api/orders?station=BAR", {
      cache: "no-store",
    })
    const data: BarItem[] = await res.json()

    const grouped: Record<number, TableGroup> = {}

    for (const item of data) {
      if (!grouped[item.tableNumber]) {
        grouped[item.tableNumber] = {
          tableNumber: item.tableNumber,
          items: [],
          submittedAt: item.submittedAt,
        }
      }

      grouped[item.tableNumber].items.push(item)
    }

    setTables(
      Object.values(grouped).sort(
        (a, b) =>
          new Date(a.submittedAt).getTime() -
          new Date(b.submittedAt).getTime()
      )
    )
  }

  useEffect(() => {
    fetchQueue()
    const interval = setInterval(fetchQueue, 5000)
    return () => clearInterval(interval)
  }, [])

  async function markBarSent(tableNumber: number) {
    await fetch("/api/orders", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        tableNumber,
        station: "BAR",
      }),
    })

    setActiveTable(null)
    fetchQueue()
  }

  async function reprintTicket(tableNumber: number) {
    await fetch("/api/orders", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tableNumber }),
    })
  }

  if (activeTable !== null) {
    const table = tables.find(t => t.tableNumber === activeTable)
    if (!table) return null

    return (
      <TicketView
        tableNumber={table.tableNumber}
        items={table.items}
        onBack={() => setActiveTable(null)}
        onReprint={() => reprintTicket(table.tableNumber)}
        onComplete={() => markBarSent(table.tableNumber)}
      />
    )
  }

  return (
    <div className="p-4 space-y-4">
      {tables.map(table => (
        <Card
          key={table.tableNumber}
          onClick={() => setActiveTable(table.tableNumber)}
          onContextMenu={(e: MouseEvent<HTMLDivElement>) => {
            e.preventDefault()
            reprintTicket(table.tableNumber)
          }}
          className="cursor-pointer"
        >
          <div className="flex justify-between items-center">
            <div>
              <div className="text-lg font-semibold">
                Table {table.tableNumber}
              </div>
              <div className="text-sm opacity-70">
                {table.items.length} bar item(s)
              </div>
            </div>

            <Badge>
              {Math.floor(
                (Date.now() -
                  new Date(table.submittedAt).getTime()) /
                  60000
              )}
              m
            </Badge>
          </div>
        </Card>
      ))}

      {tables.length === 0 && (
        <div className="opacity-60 text-center">
          No bar items waiting
        </div>
      )}
    </div>
  )
}
